jQuery(window).load(function() {

    var upgrade_notice = '<a class="upgrade-pro" target="_blank" href="https://accesspressthemes.com/wordpress-themes/the-launcher-pro/">UPGRADE TO THE LAUNCHER PRO</a>';
    upgrade_notice += '<a class="upgrade-pro" target="_blank" href="http://accesspressthemes.com/theme-demos/?theme=the-launcher-pro">THE LAUNCHER PRO DEMO</a>';
    jQuery('#customize-info .preview-notice').append(upgrade_notice);
});